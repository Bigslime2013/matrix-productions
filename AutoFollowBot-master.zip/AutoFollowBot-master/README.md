# AutoFollowBot
Instagram Bot That Helps Gain Followers Automatically

Pre-Requisites: Homebrew, Ruby
Installation: sudo gem install watir, sudo gem install pry, sudo gem install rb-readline, sudo gem install awesome_print.

Change: ENTER USERNAME HERE, ENTER PASSWORD HERE
